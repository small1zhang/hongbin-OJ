/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Page_PostVO_ } from './Page_PostVO_';

export type BaseResponse_Page_PostVO_ = {
    code?: number;
    data?: Page_PostVO_;
    message?: string;
};
