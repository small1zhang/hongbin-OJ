/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Page_QuestionVO_ } from "./Page_QuestionVO_";

export type BaseResponse_Page_QuestionVO_ = {
  code?: number;
  data?: Page_QuestionVO_;
  message?: string;
};
