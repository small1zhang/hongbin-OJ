/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Page_UserVO_ } from "./Page_UserVO_";

export type BaseResponse_Page_UserVO_ = {
  code?: number;
  data?: Page_UserVO_;
  message?: string;
};
