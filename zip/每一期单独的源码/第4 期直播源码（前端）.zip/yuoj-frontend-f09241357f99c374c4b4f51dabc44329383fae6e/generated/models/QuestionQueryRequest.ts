/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type QuestionQueryRequest = {
  answer?: string;
  content?: string;
  current?: number;
  id?: number;
  pageSize?: number;
  sortField?: string;
  sortOrder?: string;
  tags?: Array<string>;
  title?: string;
  userId?: number;
};
