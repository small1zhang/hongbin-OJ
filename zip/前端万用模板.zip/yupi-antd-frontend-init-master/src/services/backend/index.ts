// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as fileController from './fileController';
import * as postController from './postController';
import * as postFavourController from './postFavourController';
import * as postThumbController from './postThumbController';
import * as userController from './userController';
import * as wxMpController from './wxMpController';
export default {
  wxMpController,
  fileController,
  postController,
  postFavourController,
  postThumbController,
  userController,
};
