import * as api from './index';

(window as any).api = api;
