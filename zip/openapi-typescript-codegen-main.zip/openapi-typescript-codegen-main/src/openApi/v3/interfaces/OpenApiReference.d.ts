/**
 * https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.0.2.md#referenceObject
 */
export interface OpenApiReference {
    $ref?: string;
}
