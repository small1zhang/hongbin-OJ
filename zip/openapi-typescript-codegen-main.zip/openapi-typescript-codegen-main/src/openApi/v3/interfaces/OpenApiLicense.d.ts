/**
 * https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.0.2.md#licenseObject
 */
export interface OpenApiLicense {
    name: string;
    url?: string;
}
