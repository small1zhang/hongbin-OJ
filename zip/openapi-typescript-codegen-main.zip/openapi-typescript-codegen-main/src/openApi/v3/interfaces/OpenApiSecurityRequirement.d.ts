/**
 * https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.0.2.md#securityRequirementObject
 */
export interface OpenApiSecurityRequirement {
    [name: string]: string;
}
