/**
 * https://github.com/OAI/OpenAPI-Specification/blob/main/versions/2.0.md#licenseObject
 */
export interface OpenApiLicense {
    name: string;
    url?: string;
}
