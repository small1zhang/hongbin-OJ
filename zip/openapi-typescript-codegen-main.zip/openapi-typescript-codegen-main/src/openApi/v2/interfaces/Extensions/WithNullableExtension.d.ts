export interface WithNullableExtension {
    'x-nullable'?: boolean;
}
