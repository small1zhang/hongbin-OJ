export interface WithEnumExtension {
    'x-enum-varnames'?: string[];
    'x-enum-descriptions'?: string[];
}
