/**
 * https://github.com/OAI/OpenAPI-Specification/blob/main/versions/2.0.md#exampleObject
 */
export interface OpenApiExample {
    [mimetype: string]: any;
}
