export const readFile = jest.fn();
export const writeFile = jest.fn();
export const copyFile = jest.fn();
export const exists = jest.fn();
export const rmdir = jest.fn();
export const mkdir = jest.fn();
