export interface OperationError {
    code: number;
    description: string;
}
