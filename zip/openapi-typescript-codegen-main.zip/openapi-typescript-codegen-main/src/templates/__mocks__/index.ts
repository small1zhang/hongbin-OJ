export default {
    compiler: [8, '>= 4.3.0'],
    useData: true,
    main: () => {
        return '';
    },
};
